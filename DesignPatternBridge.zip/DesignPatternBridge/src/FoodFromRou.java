
public class FoodFromRou extends Feeding {

	@Override
	void strawFood() {
		System.out.println("Horse: Food from Roumania - My animal is eating some straw ");

	}

	@Override
	void grassFood() {
		System.out.println("Sheep: Food from Roumania - My animal is eating some grass");

	}

}
