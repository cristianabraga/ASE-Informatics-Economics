
public class Sheep extends Animal {

	Sheep(String name, int age, double weight, String colour, Feeding feeding) {
		super(name, age, weight, colour, feeding);
		// TODO Auto-generated constructor stub
	}

	@Override
	void about(String type) {
		SaveAnimals.getInstance().saveObject(type, this);
		// System.out.println("The sheep is "+name+", it's "+age+" years old,
		// "+"with "+weight+" kg and "+colour+" colour");
		// feeding.grassFood();

	}

	public String toString() {
		feeding.grassFood();
		return String.format("The sheep is %s, it's %d  years old, with %f kg and %s colour", name, age, weight,
				colour);

	}
}
