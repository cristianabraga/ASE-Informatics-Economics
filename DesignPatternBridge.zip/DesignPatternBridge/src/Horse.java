
public class Horse extends Animal {

	Horse(String name, int age, double weight, String colour, Feeding feeding) {
		super(name, age, weight, colour, feeding);
		// TODO Auto-generated constructor stub
	}

	@Override
	void about(String type) {
		SaveAnimals.getInstance().saveObject(type, this);

	}

	public String toString() {
		feeding.strawFood();
		return String.format("The horse is %s, it's %d  years old, with %f kg and %s colour", name, age, weight,
				colour);

	}

}
