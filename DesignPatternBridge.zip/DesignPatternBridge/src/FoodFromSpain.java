
public class FoodFromSpain extends Feeding {

	@Override
	void strawFood() {
		System.out.println("Horse: Food from Spain - My animal is eating some straw ");

	}

	@Override
	void grassFood() {
		System.out.println("Sheep: Food from Spain - My animal is eating some grass ");

	}

}
