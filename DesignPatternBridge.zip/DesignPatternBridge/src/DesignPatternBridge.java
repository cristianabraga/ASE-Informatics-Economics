
public class DesignPatternBridge {

	public static void main(String[] args) {

		Animal a = new Horse("Max", 5, 150, "brown", new FoodFromRou());
		Animal b = new Sheep("Bella", 2, 40, "white", new FoodFromRou());
		Animal c = new Horse("Marco", 7, 160, "black", new FoodFromSpain());
		Animal d = new Sheep("Rita", 2, 30, "black", new FoodFromSpain());

		a.about("txt");
		b.about("xml");
		c.about("json");

	}

}
