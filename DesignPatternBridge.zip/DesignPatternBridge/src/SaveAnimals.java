import java.beans.XMLEncoder;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

public final class SaveAnimals {
	private static SaveAnimals SINGLETON;

	private SaveAnimals() {

	}

	public static SaveAnimals getInstance() {
		if (null == SINGLETON)
			SINGLETON = new SaveAnimals();
		return SINGLETON;
	}

	public void saveObject(String type, Object obj) {

		switch (type) {

		case "txt":

			try {
				File file = new File("Text.txt");
				FileWriter fw = new FileWriter(file.getAbsoluteFile());
				BufferedWriter bw = new BufferedWriter(fw);
				System.out.println("-----Writing TXT-----");
				bw.write(obj.toString());
				bw.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		case "xml":
			try {
				FileOutputStream f = new FileOutputStream("xml.xml");
				BufferedOutputStream bf = new BufferedOutputStream(f);
				XMLEncoder xml = new XMLEncoder(bf);
				System.out.println("-----Writing XML-----");
				xml.writeObject(obj.toString());
				xml.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		case "json":
			try {
				File file = new File("json.json");
				file.createNewFile();
				FileWriter fileWriter = new FileWriter(file);
				System.out.println("-----Writing JSON-----");

				fileWriter.write(obj.toString());
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				e.printStackTrace();

			}
			break;
		}
	}
}
