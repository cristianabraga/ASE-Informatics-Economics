
public abstract class Feeding {

	abstract void strawFood();
	abstract void grassFood();
}
