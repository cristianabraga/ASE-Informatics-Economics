
public abstract class Animal {
	protected String name;
	protected double weight;
	protected int age;
	protected String colour;

	protected Feeding feeding;

	abstract void about(String type);

	Animal(String name, int age, double weight, String colour, Feeding feeding) {
		this.name = name;
		this.weight = weight;
		this.age = age;
		this.colour = colour;
		this.feeding = feeding;
	}

}
