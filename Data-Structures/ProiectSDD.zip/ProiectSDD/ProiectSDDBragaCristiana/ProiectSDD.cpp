#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <dirent.h>
#include <sys/stat.h>

typedef struct _list_t_ {
    char *string; 
    int size;
    struct _list_t_ *next;
} list_t;

typedef struct _hash_table_t_ {
    int size;      
    list_t ** table; 
} hash_table_t;

typedef struct node{
	char * data;
	int size;
	struct node * next;
} Node;

typedef struct tree {
	char * data; 
	struct nodeTree * front;
} Tree;

typedef struct nodeTree {
	struct tree * _tree;
	struct nodeTree * next;
} NodeTree;


void InsertTree(NodeTree ** root, char * name);
void infix(NodeTree * root,int index);
hash_table_t * create_hash_table(int size);
int hash(hash_table_t *hashtable, char *str);
list_t * lookup_string(hash_table_t *hashtable, char *str);
int add_string(hash_table_t *hashtable, char *str, int size);
void free_table(hash_table_t *hashtable);
void Enqueue(Node **,  char *  ,int size);
void Dequeue(Node **);
void PrintQ(Node * );
char * Top(Node ** );
void returnArrayofString(char *, Node **);
void freeQueue(Node **);
int interpretCommand(Node ** head, hash_table_t * , NodeTree **, Node **) ;
void printFiles(char * path, hash_table_t *);
void listDirTREE(char * path, NodeTree ** root, char * type, int SIZE);
int stringToNumber(char * snum);
int getSize(char * path);
void freeTree(NodeTree ** list);
void printHash(hash_table_t *, Node ** );
void printToFile(char * filename, Node * getList);
char * returnCurrentTime();

int queueDimension = 0;
char GlobalBuff[100];

int main()
{
	
	Node * front = NULL;
	Node * getList = NULL;
	hash_table_t * myHash = create_hash_table(20);
	NodeTree * listTree = NULL;

	FILE * log = fopen("log.txt","w");
	if(log == NULL)
		exit(0);

	
	while(1){
		char * string  = (char*)malloc(50);
		printf("Enter command : ");
		gets(string);

		fprintf(log, "%s        %s", string, returnCurrentTime());
		if(string[0] =='\0'){
			printf("Command unknown\n");
			fprintf(log, "fail\n");
			continue;
		}

		if(strncmp(string, "exit", 4) == 0)
			break;
		returnArrayofString(string, &front);
		if(interpretCommand(&front, myHash, &listTree, &getList) == 1){
			fprintf(log, "succes\n");
		} else { 
			fprintf(log, "fail\n");
		}


		free(string);
		freeTree(&listTree);
		free(listTree);
		listTree = NULL;
		freeQueue(&front);
		
	}

	
	fclose(log);

	return 0;
}
int interpretCommand(Node ** head, hash_table_t * myHash, NodeTree ** listTree, Node ** getList) {
	if(*head == NULL){
		printf("Command unknown!\n");
		return 0;
	}

	if(queueDimension == 0){
		printf("Enter a command!\n");
		return 0;
	}
	
	char * type = (char*)malloc(50);
	strcpy(type, Top(head));
	if(strcmp(type, "list") == 0){
		char * path = (char*)malloc(50);
		if(queueDimension == 0){
			strcpy(path, ".");
		} else {
			strcpy(path, Top(head));
		}
		printFiles(path, myHash);
		return 1;

	} else if(strcmp(type, "filter") == 0){
		if(queueDimension == 0){
			strcpy(GlobalBuff, ".");
			listDirTREE(".", listTree, "-b", 0);
		} else if (queueDimension == 1) {
			char * buff = (char*)malloc(50);
			strcpy(buff, Top(head));
			if(strchr(buff, '\\') != NULL || strstr(buff, "..") != NULL){ 
				strcpy(GlobalBuff, buff);
				listDirTREE(buff, listTree, "-b", 0);
			} else if((strncmp(buff, "-d", 2) == 0) || (strncmp(buff, "-f", 2) == 0)){
				strcpy(GlobalBuff, ".");
				listDirTREE(".", listTree, buff, 0);
			} else { 
				strcpy(GlobalBuff, ".");
				listDirTREE(".", listTree, "-b", stringToNumber(buff) * 1000);
			}
		} else if (queueDimension == 2) {
			char * buff1 = (char*)malloc(50);
			strcpy(buff1, Top(head));
			char * buff2 = (char*)malloc(50);
			strcpy(buff2, Top(head));
			if(strchr(buff1, '\\') != NULL || strstr(buff1, "..") != NULL){ 
				if((strncmp(buff2, "-d", 2) == 0) || (strncmp(buff2, "-f", 2) == 0)){
					strcpy(GlobalBuff, buff1);
					listDirTREE(buff1, listTree, buff2, 0);
				} else { 
					strcpy(GlobalBuff, buff1);
					listDirTREE(buff1, listTree, "-b", stringToNumber(buff2) * 1000);
				}
			} else { 
				strcpy(GlobalBuff, ".");
				listDirTREE(".", listTree, buff2, stringToNumber(Top(head)) * 1000);
			}
		} else {
			char * buff = (char*)malloc(50);
			strcpy(buff, Top(head));
			char * type = (char*)malloc(50);
			strcpy(type, Top(head));
			
			strcpy(GlobalBuff, buff);
			listDirTREE(buff, listTree, type, stringToNumber(Top(head)) * 1000);
		}
		infix(*listTree, 0);
		return 1;
	} else if(strcmp(type, "get") == 0){
		printHash(myHash, getList);
		free_table(myHash);
		PrintQ(*getList);
		return 1;
	} else if(strcmp(type, "saveget") == 0){
		
		char * buff = (char*)malloc(50);
		strcpy(buff, Top(head));

		if(buff[0] == '\0')
			printf("enter another parameter next time!\n");

		
		if(buff == NULL)

		printToFile(buff, *getList);
		return 1;

	} else {
		
		printf("Command unknown\n");
		return 0;
	}
}

void printToFile(char * filename, Node * getList){
	FILE * src = fopen(filename, "w");
	if(src == NULL){
		exit(0);
	}

	fprintf(src,"%s\n", returnCurrentTime());
	Node * aux = getList;
	while(aux != NULL){
		fprintf(src, "%s %d\n", aux->data, aux->size);
		aux = aux->next;
	}

	fclose(src);
}

void printHash(hash_table_t * myHash, Node ** getList){
	int i = 0;
	for(i = 0; i < myHash->size; i ++){
		if(myHash->table[i] != NULL){
			list_t * aux = myHash->table[i];
			while(aux != NULL){
				Enqueue(getList, aux->string, aux->size);
				aux = aux->next;
			}
		}
	}
}

void freeTree(NodeTree ** list){
	if(*list == NULL)
		return;

	
	NodeTree * aux = (*list)->_tree->front;
	while(aux != NULL){
		freeTree(&aux);
		NodeTree * temp = aux;
		aux = aux->next;
		free(temp);
	}
	free((*list)->_tree->data);
	free((*list)->_tree);


}
int getSize(char * path){
	struct stat st;
	stat(path, &st);
	return st.st_size;
}
int stringToNumber(char* snum)
{
	 int nInt = 0;
	 int index = 0;
	 while(snum[index])
	 {
	    if(!nInt)
	        nInt= ( (int) snum[index]) - 48;
	    else
	    {
	        nInt = (nInt *= 10) + ((int) snum[index] - 48);
	    }
	    index++;
	 }
	 return nInt;
}

void printFiles(char * path, hash_table_t * myHash){
	DIR *dir;
	struct dirent *ent;
	char * cpypath = (char*)malloc(50);
	strcpy(cpypath, path);
	strcat(cpypath, "\\");
	if ((dir = opendir (path)) != NULL) {
		printf("succes\n");
	  while ((ent = readdir (dir)) != NULL) {
	  	
	  	if (!strcmp(ent->d_name, ".") || !strcmp(ent->d_name, "..") )
        {
        } else {
        	char buff[50];
        	strcpy(buff, cpypath);
        	strcat(buff, ent->d_name);
        	printf("%s\n",buff);
        	add_string(myHash, ent->d_name,getSize(buff));
        }
	  }
	  closedir (dir);
	} else {
		  printf("fail\n");
	}
}


void listDirTREE(char * path, NodeTree ** root, char * type, int SIZE){
	
	char cpybuff[50];
	strcpy(cpybuff, GlobalBuff);
	InsertTree(root, path);

	printf("path - %s\n", path);
	DIR* dir;
	struct dirent *ent;
	if((dir=opendir(GlobalBuff)) != NULL){
		
		while (( ent = readdir(dir)) != NULL){
			if(strcmp(ent->d_name, ".") != 0  && strcmp(ent->d_name, "..") != 0){
				if(ent->d_type == DT_DIR){
						strcat(GlobalBuff,"\\");
						strcat(GlobalBuff,ent->d_name);
						listDirTREE(GlobalBuff, &(*root)->_tree->front, type, SIZE); 

						strcpy(GlobalBuff,cpybuff);
				} else {
					if(strncmp(type, "-b", 2) == 0 || strncmp(type, "-f", 2) == 0){
						char * string = (char*)malloc(50);
						sprintf(string, "%s\\%s",path, ent->d_name);

						if(SIZE < getSize(string)){

							NodeTree * temp = *root;
							if(temp == NULL){

							} else {
								while(temp->next != NULL)
									temp = temp->next;

							}
							
							printf("%s\n", string);
							InsertTree(&temp->_tree->front, string);
						}
						free(string);
					}
				}
			}
		}
		closedir(dir);
	}
}


void InsertTree(NodeTree ** root, char * name){


	NodeTree * newNode = (NodeTree*)malloc(sizeof(NodeTree));

	newNode->next = NULL;
	newNode->_tree = (Tree*)malloc(sizeof(Tree));
	newNode->_tree->front = NULL;	
	newNode->_tree->data = (char*)malloc(50);
	strcpy(newNode->_tree->data, name);

	if(*root == NULL){
		*root = newNode;
		return;
	}

	NodeTree * copy_root = *root;

	while(copy_root->next != NULL)
		copy_root = copy_root->next;

	copy_root->next = newNode;
}


void infix(NodeTree * root, int level)
{
	if(root == NULL)
		return;

	int i = 0;
	for(i = 0; i < level ; i++)
		printf("\t");
	printf("%s\n", root->_tree->data);
	NodeTree * aux = root->_tree->front;
	while(aux != NULL){
		infix(aux, level + 1);
		aux = aux->next;
	}

}

hash_table_t *create_hash_table(int size)
{
    hash_table_t *new_table;
    
    if (size < 1) 
		return NULL; 
	
    new_table = (hash_table_t *)malloc(sizeof(hash_table_t));
    new_table->table = (list_t **)malloc(sizeof(list_t *) * size);
    int i = 0;
    for(i=0; i<size; i++) new_table->table[i] = NULL;
		 new_table->size = size;

    return new_table;
}

int hash(hash_table_t *hashtable, char *str)
{
    unsigned long hash = 1;
    int c;

    while (c = *str++)
        hash = ((hash << 5) + hash) + c; 

    return hash % hashtable->size;
}



list_t *lookup_string(hash_table_t *hashtable, char *str)
{
    
    unsigned int hashval = hash(hashtable, str);
	list_t *list = hashtable->table[hashval];
	while(list != NULL){
		if (strcmp(str, list->string) == 0) 
			return list;
		list = list->next;
	}
    return NULL;
}

int add_string(hash_table_t *hashtable, char *str, int size)
{
    unsigned int hashval = hash(hashtable, str);

    list_t * new_list = (list_t *)malloc(sizeof(list_t));


    if (lookup_string(hashtable, str) != NULL) 
		return 2;


    new_list->string = (char*)malloc(50);
	strcpy(new_list->string, str);
	new_list->size = size;
    new_list->next = hashtable->table[hashval];
    hashtable->table[hashval] = new_list;

    return 0;
}

void free_table(hash_table_t *hashtable)
{
    int i;
    list_t *list, *temp;

    if (hashtable==NULL) 
		return;

    for(i=0; i< hashtable->size; i++) {
        list = hashtable->table[i];
        while(list!=NULL) {
            temp = list;
            list = list->next;
            free(temp->string);
            free(temp);
        }
    }

    free(hashtable->table);
    free(hashtable);
}
void Enqueue(Node ** front, char * msg,int size){
	if(msg[0] =='\0')
		return;

	queueDimension ++;
	Node * nou = (Node*)malloc(sizeof(Node));

	nou->data = (char*)malloc(50);
	nou->size = size;



	strcpy(nou->data, msg);
	nou->next = NULL;
	if(*front == NULL) {
		(*front) = nou;
		return;
	}


	Node * temp = *front;
	while(temp->next != NULL)
		temp = temp->next;

	temp->next = nou;
}
void Dequeue(Node ** front){
	if(*front == NULL){
		return;
	}
	queueDimension -- ;

	Node * temp = (*front);
	(*front) = (*front)->next;
	free(temp->data);
	free(temp);
	
}
void PrintQ(Node * front){
	Node * temp = front;
	while(temp != NULL){
		printf("%s ",temp->data);
		temp = temp->next;
	}
	printf("\n");
}
char * Top(Node ** front){
	if(*front == NULL)
		return "";

	Node * temp = *front;
	char * result = (char*)malloc(50);
	strcpy(result, temp->data);
	*front = (*front)->next;

	free(temp->data);
	free(temp);

	queueDimension --;
	return result;
}
void returnArrayofString(char * _string, Node ** front){

	char * buff;
	char s[2] = " ";
    char * string = (char*)malloc(strlen(_string) + 1);
    strcpy(string,_string);

    buff = strtok (_string, s);
    Enqueue(front, buff, 0);

    while(1){

    	buff = strtok(NULL, s);
    	
    	if(buff == NULL)
    		return;

    	Enqueue(front, buff, 0);
    }
}
void freeQueue(Node ** front){
	while(*front != NULL){
		Dequeue(front);
	}
	queueDimension = 0;
}
char * returnCurrentTime(){
  time_t rawtime;
  struct tm * timeinfo;

  time ( &rawtime );
  timeinfo = localtime ( &rawtime );
  return asctime (timeinfo);
}
