package eu.cegeka.DesignPatternAdapter;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class Adapter {
	private Connection con;
	private PreparedStatement ps1, ps2, ps3, ps4;
	private static Adapter SINGLETON = null;

	private Adapter() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/temacristianacegeka", "root", "");
			ps1 = con.prepareStatement("INSERT INTO carDB VALUES (?,?,?,?,?,?,?,?)");
			ps2 = con.prepareStatement("UPDATE carDB SET ?=? where ?=?");
			ps3 = con.prepareStatement("SELECT MAX(id) from carDB");
			ps4 = con.prepareStatement("DELETE FROM carDB WHERE id=?");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public CarDB getCarDB(Car car) {
		int id = 1;
		try {
			ResultSet rs = ps3.executeQuery();
			if (rs.next())
				id = rs.getInt(1) + 1;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		CarDB carDB = new CarDB(id, car.getName(), car.getColour(), car.getEngine_cc(), car.getAvg_consumption(),
				car.getSpeedMax());
		return carDB;

	}

	public static Adapter getInstance() {
		if (null == SINGLETON)
			SINGLETON = new Adapter();
		return SINGLETON;
	}

	public void addCar(Car car) {
		CarDB carDB = Adapter.getInstance().getCarDB(car);
		car.setKey(carDB.getId());
		try {
			ps1.setInt(1, carDB.getId());
			ps1.setNString(2, carDB.getName());
			ps1.setNString(3, carDB.getColour());
			ps1.setDouble(4, carDB.getEngine_cc());
			ps1.setDouble(5, carDB.getAvg_consumption());
			ps1.setDouble(6, carDB.getSpeedMax());
			ps1.setDouble(7, carDB.getCreatedAt());
			ps1.setDouble(8, carDB.getUpdatedAt());
			ps1.executeUpdate();
			System.out.println("Add-Done!");
		} catch (SQLException ex) {
			Logger.getLogger(Adapter.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	public void deleteCar(Car car) {
		try {
			ps4.setInt(1, car.getKey());
			ps4.executeUpdate();
			System.out.println("Delete-Done!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
