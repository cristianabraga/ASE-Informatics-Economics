package eu.cegeka.DesignPatternAdapter;

public class CarDB extends Car {

	public int id;
    public double createdAt;
	public double updatedAt;
	

	public CarDB(int id,String name, String colour, double engine_cc, double avg_consumption, double speedMax) {
		super(name, colour, engine_cc, avg_consumption, speedMax);
		this.createdAt = System.currentTimeMillis();	
		this.updatedAt = System.currentTimeMillis();
		this.id = id;
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(double createdAt) {
		this.createdAt = createdAt;
	}

	public double getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(double updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public double getEngine_cc() {
		return engine_cc;
	}

	public void setEngine_cc(double engine_cc) {
		this.engine_cc = engine_cc;
	}

	public double getAvg_consumption() {
		return avg_consumption;
	}

	public void setAvg_consumption(double avg_consumption) {
		this.avg_consumption = avg_consumption;
	}

	public double getSpeedMax() {
		return speedMax;
	}

	public void setSpeedMax(double speedMax) {
		this.speedMax = speedMax;
	}

}
