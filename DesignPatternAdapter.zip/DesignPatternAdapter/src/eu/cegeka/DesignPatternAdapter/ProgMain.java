package eu.cegeka.DesignPatternAdapter;

public class ProgMain {

	public static void main(String[] args) {
		Car c= new Car("AudiR8","black",1800,10.3,300);
		Car c1=new Car("BMWX5","grey",1600,9.3,280);
		Car c2=new Car("Ferrari","red",2000,11,363);
		Car c3=new Car("LexusNX200","black",3456,9.7,270);
		Adapter.getInstance().addCar(c);
		Adapter.getInstance().addCar(c1);
		Adapter.getInstance().addCar(c2);
		Adapter.getInstance().addCar(c3);
		Adapter.getInstance().deleteCar(c1);
		

	}

}
