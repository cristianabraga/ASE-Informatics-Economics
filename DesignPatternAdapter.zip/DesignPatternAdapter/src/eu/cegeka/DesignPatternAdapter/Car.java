package eu.cegeka.DesignPatternAdapter;

public class Car {

	protected String name;
	protected String colour;
	protected double engine_cc;
	protected double avg_consumption;
	protected double speedMax;
	protected int key;
	public Car(String name, String colour, double engine_cc, double avg_consumption, double speedMax) {
		super();
		this.name = name;
		this.colour = colour;
		this.engine_cc = engine_cc;
		this.avg_consumption = avg_consumption;
		this.speedMax = speedMax;
	}

	public int getKey() {
		return key;
	}

	public void setKey(int key) {
		this.key = key;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public double getEngine_cc() {
		return engine_cc;
	}

	public void setEngine_cc(double engine_cc) {
		this.engine_cc = engine_cc;
	}

	public double getAvg_consumption() {
		return avg_consumption;
	}

	public void setAvg_consumption(double avg_consumption) {
		this.avg_consumption = avg_consumption;
	}

	public double getSpeedMax() {
		return speedMax;
	}

	public void setSpeedMax(double speedMax) {
		this.speedMax = speedMax;
	}

}
